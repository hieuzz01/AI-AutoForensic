@echo off
setlocal
echo ===================================================================
echo             STOPPING ALL V-AUTOFOR ^& FORBRAIN SERVICES
echo ===================================================================
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8787, 5000 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Write-Host '  [-] Dung process ID:' $_; Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"
taskkill /F /IM reasonix.exe >nul 2>&1
echo   [+] Da dung tat ca cac service (Port 8787 ^& Port 5000) sach se!
echo ===================================================================
